# Übersicht Widget - Ethereum/USD price

![Screenshot](https://github.com/AdrienKuhn/ubersicht-ethereum-usd-price/blob/master/screenshot.png)

Based on [Daniel Spillere Andrade BTC widget](https://github.com/felixhageloh/uebersicht-widgets/tree/master/btc). 
